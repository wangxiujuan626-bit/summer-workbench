#!/usr/bin/env python3
"""Serve the local workbench and provide same-Wi-Fi pairing/sync APIs."""

import json
import os
import secrets
import socket
import time
import threading
import uuid
from http import HTTPStatus
from http.cookies import SimpleCookie
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse


ROOT = os.path.dirname(os.path.abspath(__file__))
DATA_PATH = os.environ.get("SUMMER_WORKBENCH_DATA_PATH", os.path.join(ROOT, ".summer-workbench-local.json"))
DEVICE_COOKIE = "summer_local_device"
MAX_BODY = 2_000_000
PORT = int(os.environ.get("SUMMER_WORKBENCH_PORT", "8765"))


def clean_name(value):
    return str(value or "").strip().replace("<", "").replace(">", "")[:16]


def clean_state(value):
    if not isinstance(value, dict):
        return {}
    encoded = json.dumps(value, ensure_ascii=False)
    if len(encoded) > 250_000:
        raise ValueError("工作台记录太大，已拒绝本次同步")
    return value


def empty_data():
    return {"workspaces": {}, "devices": {}, "pairCodes": {}}


def load_data():
    try:
        with open(DATA_PATH, "r", encoding="utf-8") as handle:
            data = json.load(handle)
        if not isinstance(data, dict):
            return empty_data()
        data.setdefault("workspaces", {})
        data.setdefault("devices", {})
        data.setdefault("pairCodes", {})
        return data
    except (OSError, json.JSONDecodeError):
        return empty_data()


def save_data(data):
    temporary = f"{DATA_PATH}.tmp"
    with open(temporary, "w", encoding="utf-8") as handle:
        json.dump(data, handle, ensure_ascii=False, indent=2)
    os.replace(temporary, DATA_PATH)


def now_ms():
    return int(time.time() * 1000)


def new_workspace():
    timestamp = now_ms()
    return {
        "displayName": "",
        "avatarUrl": "/avatar-default.svg",
        "state": {},
        "revision": 1,
        "updatedAt": timestamp,
    }


def ensure_device(data, token=None):
    if token and token in data["devices"]:
        device = data["devices"][token]
        device["lastSeenAt"] = now_ms()
        return token, device, False
    token = secrets.token_urlsafe(24)
    workspace_id = str(uuid.uuid4())
    data["devices"][token] = {
        "workspaceId": workspace_id,
        "lastSeenAt": now_ms(),
    }
    data["workspaces"][workspace_id] = new_workspace()
    return token, data["devices"][token], True


def workspace_payload(data, workspace_id):
    workspace = data["workspaces"].get(workspace_id) or new_workspace()
    return {
        "displayName": workspace.get("displayName", ""),
        "avatarUrl": workspace.get("avatarUrl") or "/avatar-default.svg",
        "state": workspace.get("state") or {},
        "revision": int(workspace.get("revision", 1)),
        "updatedAt": int(workspace.get("updatedAt", now_ms())),
    }


def local_ip():
    try:
        probe = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        probe.connect(("192.0.2.1", 80))
        address = probe.getsockname()[0]
        probe.close()
        return address
    except OSError:
        return "127.0.0.1"


class WorkbenchHandler(SimpleHTTPRequestHandler):
    server_version = "SummerWorkbenchLocal/1.0"

    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=ROOT, **kwargs)

    def log_message(self, format_string, *args):
        if self.path.startswith("/api/local/"):
            return
        super().log_message(format_string, *args)

    def send_json(self, status, payload, token=None):
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(body)))
        if token:
            self.send_header("Set-Cookie", f"{DEVICE_COOKIE}={token}; Path=/; Max-Age=31536000; SameSite=Lax")
        self.end_headers()
        self.wfile.write(body)

    def read_json(self):
        length = int(self.headers.get("Content-Length", "0"))
        if length > MAX_BODY:
            raise ValueError("工作台数据太大，已拒绝本次同步")
        raw = self.rfile.read(length).decode("utf-8")
        return json.loads(raw or "{}")

    def device_token(self):
        cookies = SimpleCookie(self.headers.get("Cookie", ""))
        return cookies.get(DEVICE_COOKIE).value if cookies.get(DEVICE_COOKIE) else None

    def api(self):
        parsed = urlparse(self.path)
        return parsed.path if parsed.path.startswith("/api/local/") else None

    def do_OPTIONS(self):
        if self.api():
            self.send_response(HTTPStatus.NO_CONTENT)
            self.send_header("Access-Control-Allow-Origin", self.headers.get("Origin", "*"))
            self.send_header("Access-Control-Allow-Methods", "GET,POST,PUT,OPTIONS")
            self.send_header("Access-Control-Allow-Headers", "content-type")
            self.end_headers()
            return
        self.send_error(HTTPStatus.NOT_FOUND)

    def do_GET(self):
        path = self.api()
        if not path:
            return super().do_GET()
        with open_lock():
            data = load_data()
            token, device, is_new = ensure_device(data, self.device_token())
            if path == "/api/local/health":
                save_data(data)
                self.send_json(HTTPStatus.OK, {"ok": True, "mode": "local-lan", "lanUrl": f"http://{local_ip()}:{PORT}/"}, token if is_new else None)
                return
            if path == "/api/local/workspace":
                save_data(data)
                self.send_json(HTTPStatus.OK, workspace_payload(data, device["workspaceId"]), token if is_new else None)
                return
            self.send_json(HTTPStatus.NOT_FOUND, {"error": "本地同步地址不存在"})

    def do_POST(self):
        path = self.api()
        if not path:
            self.send_error(HTTPStatus.NOT_FOUND)
            return
        try:
            body = self.read_json()
            with open_lock():
                data = load_data()
                token, device, is_new = ensure_device(data, self.device_token())
                if path == "/api/local/pair/start":
                    code = f"{secrets.randbelow(1_000_000):06d}"
                    expires_at = now_ms() + 5 * 60 * 1000
                    data["pairCodes"][code] = {
                        "workspaceId": device["workspaceId"],
                        "creatorToken": token,
                        "expiresAt": expires_at,
                    }
                    save_data(data)
                    self.send_json(HTTPStatus.OK, {"code": code, "expiresAt": expires_at, "lanUrl": f"http://{local_ip()}:{PORT}/"}, token if is_new else None)
                    return
                if path == "/api/local/pair/join":
                    code = str(body.get("code", "")).replace(" ", "")
                    pair = data["pairCodes"].get(code)
                    if not pair or pair["expiresAt"] < now_ms():
                        self.send_json(HTTPStatus.BAD_REQUEST, {"error": "同步码无效或已过期"}, token if is_new else None)
                        return
                    if pair["creatorToken"] == token:
                        self.send_json(HTTPStatus.BAD_REQUEST, {"error": "不能连接当前这台设备"}, token if is_new else None)
                        return
                    device["workspaceId"] = pair["workspaceId"]
                    del data["pairCodes"][code]
                    save_data(data)
                    self.send_json(HTTPStatus.OK, {"workspace": workspace_payload(data, device["workspaceId"])}, token if is_new else None)
                    return
                if path == "/api/local/reset":
                    data["workspaces"][device["workspaceId"]] = new_workspace()
                    save_data(data)
                    self.send_json(HTTPStatus.OK, workspace_payload(data, device["workspaceId"]), token if is_new else None)
                    return
                self.send_json(HTTPStatus.NOT_FOUND, {"error": "本地同步地址不存在"})
        except (ValueError, json.JSONDecodeError) as error:
            self.send_json(HTTPStatus.BAD_REQUEST, {"error": str(error) or "请求格式不正确"})

    def do_PUT(self):
        path = self.api()
        if path != "/api/local/workspace":
            self.send_error(HTTPStatus.NOT_FOUND)
            return
        try:
            body = self.read_json()
            with open_lock():
                data = load_data()
                token, device, is_new = ensure_device(data, self.device_token())
                current = workspace_payload(data, device["workspaceId"])
                requested_revision = int(body.get("revision", 0))
                if requested_revision != current["revision"]:
                    self.send_json(HTTPStatus.CONFLICT, {"error": "另一台设备已有更新", "workspace": current}, token if is_new else None)
                    return
                avatar_url = str(body.get("avatarUrl") or current["avatarUrl"])
                if len(avatar_url) > 1_500_000:
                    raise ValueError("头像文件太大，请换一张小一点的图片")
                workspace = data["workspaces"][device["workspaceId"]]
                workspace.update({
                    "displayName": clean_name(body.get("displayName")),
                    "avatarUrl": avatar_url,
                    "state": clean_state(body.get("state")),
                    "revision": current["revision"] + 1,
                    "updatedAt": now_ms(),
                })
                save_data(data)
                self.send_json(HTTPStatus.OK, workspace_payload(data, device["workspaceId"]), token if is_new else None)
        except (ValueError, json.JSONDecodeError) as error:
            self.send_json(HTTPStatus.BAD_REQUEST, {"error": str(error) or "请求格式不正确"})


_lock = threading.Lock()


def open_lock():
    return _lock


if __name__ == "__main__":
    os.makedirs(ROOT, exist_ok=True)
    server = ThreadingHTTPServer(("0.0.0.0", PORT), WorkbenchHandler)
    print(f"Summer 工作台已启动: http://127.0.0.1:{PORT}/", flush=True)
    print(f"同一 Wi-Fi 的手机打开: http://{local_ip()}:{PORT}/", flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
