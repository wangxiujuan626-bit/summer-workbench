@echo off
cd /d "%~dp0"
where node >nul 2>nul
if %errorlevel%==0 if exist "%~dp0workbench-connector\src\bridge.mjs" start "Summer Workbench Connector" /min cmd /c "cd /d ""%~dp0workbench-connector"" && node src\bridge.mjs"
where py >nul 2>nul
if %errorlevel%==0 (
  start "" http://127.0.0.1:8765/
  py local_server.py
  exit /b
)
where python >nul 2>nul
if %errorlevel%==0 (
  start "" http://127.0.0.1:8765/
  python local_server.py
  exit /b
)
echo 需要安装 Python 3 后再启动。
pause
