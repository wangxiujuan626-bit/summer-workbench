#!/bin/sh
set -eu
cd "$(dirname "$0")"
port_file=".summer-workbench-port"
connector_pid=''
server_pid=''
cleanup() {
  if [ -n "$connector_pid" ]; then kill "$connector_pid" >/dev/null 2>&1 || true; fi
  if [ -n "$server_pid" ]; then kill "$server_pid" >/dev/null 2>&1 || true; fi
}
trap cleanup EXIT INT TERM
rm -f "$port_file"
if command -v node >/dev/null 2>&1 && [ -f "workbench-connector/src/bridge.mjs" ]; then
  (cd workbench-connector && node src/bridge.mjs) >/dev/null 2>&1 &
  connector_pid=$!
fi
start_server() {
  "$1" local_server.py &
  server_pid=$!
  tries=0
  while [ ! -s "$port_file" ] && kill -0 "$server_pid" >/dev/null 2>&1 && [ "$tries" -lt 100 ]; do
    sleep 0.1
    tries=$((tries + 1))
  done
  if [ -s "$port_file" ]; then
    port=$(cat "$port_file")
    open "http://127.0.0.1:$port/" >/dev/null 2>&1 || true
  else
    echo "本地服务启动失败，请重新双击 start.command。"
  fi
  wait "$server_pid"
}
if command -v python3 >/dev/null 2>&1; then start_server python3; exit; fi
if command -v python >/dev/null 2>&1; then start_server python; exit; fi
echo "需要安装 Python 3 后再启动。"
read -r _
