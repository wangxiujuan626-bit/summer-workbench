#!/bin/sh
set -eu
cd "$(dirname "$0")"
port=8765
connector_pid=''
server_pid=''
cleanup() {
  if [ -n "$connector_pid" ]; then kill "$connector_pid" >/dev/null 2>&1 || true; fi
  if [ -n "$server_pid" ]; then kill "$server_pid" >/dev/null 2>&1 || true; fi
}
trap cleanup EXIT INT TERM
if command -v node >/dev/null 2>&1 && [ -f "workbench-connector/src/bridge.mjs" ]; then
  (cd workbench-connector && node src/bridge.mjs) >/dev/null 2>&1 &
  connector_pid=$!
fi
if command -v python3 >/dev/null 2>&1; then
  (sleep 1; open "http://127.0.0.1:$port/") >/dev/null 2>&1 &
  python3 local_server.py &
  server_pid=$!
  wait "$server_pid"
fi
if command -v python >/dev/null 2>&1; then
  (sleep 1; open "http://127.0.0.1:$port/") >/dev/null 2>&1 &
  python local_server.py &
  server_pid=$!
  wait "$server_pid"
fi
echo "需要安装 Python 3 后再启动。"
read -r _
