#!/bin/sh
set -eu
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
PARENT="$(dirname "$ROOT")"
MANIFEST_URL="https://raw.githubusercontent.com/wangxiujuan626-bit/summer-workbench/main/public/update.json"
CURRENT_VERSION="0.0.0"
if [ -f "$ROOT/VERSION" ]; then CURRENT_VERSION=$(tr -d '\r\n ' < "$ROOT/VERSION"); fi
MANIFEST_FILE=$(mktemp "/tmp/summer-workbench-manifest.XXXXXX")
cleanup_manifest() { rm -f "$MANIFEST_FILE"; }
trap cleanup_manifest EXIT

if ! command -v curl >/dev/null 2>&1 || ! command -v unzip >/dev/null 2>&1; then exit 0; fi
if ! curl -fsSL --max-time 5 "$MANIFEST_URL?t=$(date +%s)" -o "$MANIFEST_FILE"; then exit 0; fi
REMOTE_VERSION=$(sed -n 's/.*"version"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p' "$MANIFEST_FILE" | head -n 1)
PACKAGE_URL=$(sed -n 's/.*"packageUrl"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p' "$MANIFEST_FILE" | head -n 1)
if [ -z "$REMOTE_VERSION" ] || [ -z "$PACKAGE_URL" ]; then exit 0; fi

VERSION_IS_NEWER=$(awk -v a="$REMOTE_VERSION" -v b="$CURRENT_VERSION" 'BEGIN { split(a,A,"."); split(b,B,"."); for (i=1;i<=3;i++) { if ((A[i]+0)>(B[i]+0)) { print 1; exit } if ((A[i]+0)<(B[i]+0)) { print 0; exit } } print 0 }')
if [ "$VERSION_IS_NEWER" != "1" ]; then exit 0; fi

UPDATE_DIR=$(mktemp -d "$PARENT/.summer-workbench-update.XXXXXX")
cleanup_update() { rm -rf "$UPDATE_DIR"; rm -f "$MANIFEST_FILE"; }
trap cleanup_update EXIT
if ! curl -fsSL --max-time 90 "$PACKAGE_URL" -o "$UPDATE_DIR/update.zip"; then exit 0; fi
mkdir "$UPDATE_DIR/unpacked"
if ! unzip -tq "$UPDATE_DIR/update.zip" >/dev/null || ! unzip -q "$UPDATE_DIR/update.zip" -d "$UPDATE_DIR/unpacked"; then exit 0; fi
NEW="$UPDATE_DIR/unpacked/Summer工作台-Lite"
if [ ! -f "$NEW/local_server.py" ] || [ ! -f "$NEW/index.html" ] || [ ! -f "$NEW/start.command" ] || [ ! -f "$NEW/VERSION" ]; then exit 0; fi
if [ "$(tr -d '\r\n ' < "$NEW/VERSION")" != "$REMOTE_VERSION" ]; then exit 0; fi
# Preserve a legacy workspace in the installation folder during the first update.
# Newer versions also keep a separate per-user data file, never inside the download.
if [ -f "$ROOT/.summer-workbench-local.json" ]; then
  cp "$ROOT/.summer-workbench-local.json" "$NEW/.summer-workbench-local.json"
fi
BACKUP=$(mktemp -d "$PARENT/.summer-workbench-previous.XXXXXX")
rmdir "$BACKUP"
if ! mv "$ROOT" "$BACKUP"; then exit 1; fi
if ! mv "$NEW" "$ROOT"; then
  mv "$BACKUP" "$ROOT"
  echo "更新未完成，已恢复原版。" >&2
  exit 1
fi
echo "已更新到 v${REMOTE_VERSION}；上一版保留在 $BACKUP" >&2
