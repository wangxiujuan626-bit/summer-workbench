param()
$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$ManifestUrl = "https://raw.githubusercontent.com/wangxiujuan626-bit/summer-workbench/main/public/update.json"
$VersionFile = Join-Path $Root "VERSION"
$CurrentVersion = [version]"0.0.0"
if (Test-Path $VersionFile) { $CurrentVersion = [version]((Get-Content $VersionFile -Raw).Trim()) }
try { $Manifest = Invoke-RestMethod -Uri ($ManifestUrl + "?t=" + [DateTimeOffset]::UtcNow.ToUnixTimeSeconds()) -TimeoutSec 5 } catch { exit 0 }
if (-not $Manifest.version -or -not $Manifest.packageUrl) { exit 0 }
try { $RemoteVersion = [version]$Manifest.version } catch { exit 0 }
if ($RemoteVersion -le $CurrentVersion) { exit 0 }
$UpdateRoot = Join-Path ([IO.Path]::GetTempPath()) ("summer-workbench-update-" + [guid]::NewGuid().ToString())
$ZipPath = Join-Path $UpdateRoot "update.zip"
$ExtractPath = Join-Path $UpdateRoot "unpacked"
try {
  New-Item -ItemType Directory -Path $ExtractPath -Force | Out-Null
  Invoke-WebRequest -Uri $Manifest.packageUrl -OutFile $ZipPath -TimeoutSec 90
  Expand-Archive -Path $ZipPath -DestinationPath $ExtractPath -Force
  $Source = Join-Path $ExtractPath "Summer工作台-Lite"
  if (-not (Test-Path (Join-Path $Source "local_server.py")) -or
      -not (Test-Path (Join-Path $Source "index.html")) -or
      -not (Test-Path (Join-Path $Source "VERSION"))) { throw "安装包缺少必要文件" }
  if ((Get-Content (Join-Path $Source "VERSION") -Raw).Trim() -ne $Manifest.version) { throw "安装包版本与更新通知不符" }
  # Keep the previous files in a recoverable sibling directory. User data is
  # never copied into a downloadable package and is not deleted on failure.
  $Backup = Join-Path (Split-Path -Parent $Root) (".summer-workbench-previous-" + [guid]::NewGuid().ToString())
  New-Item -ItemType Directory -Path $Backup | Out-Null
  Get-ChildItem -LiteralPath $Root -Force | Copy-Item -Destination $Backup -Recurse -Force
  try {
    Get-ChildItem -LiteralPath $Source -Force | Copy-Item -Destination $Root -Recurse -Force
    Write-Host "已更新到 v$($Manifest.version)；上一版保留在 $Backup"
  } catch {
    Get-ChildItem -LiteralPath $Backup -Force | Copy-Item -Destination $Root -Recurse -Force
    throw "更新失败，已尝试恢复旧版；备份在 $Backup"
  }
} catch {
  Write-Warning $_
} finally {
  Remove-Item $UpdateRoot -Recurse -Force -ErrorAction SilentlyContinue
}
