@echo off
cd /d "%~dp0"
if exist "%~dp0update.ps1" powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0update.ps1"
where node >nul 2>nul
if %errorlevel%==0 if exist "%~dp0workbench-connector\src\bridge.mjs" start "Summer Workbench Connector" /min cmd /c "cd /d ""%~dp0workbench-connector"" && node src\bridge.mjs"
where py >nul 2>nul
if %errorlevel%==0 (
  del "%~dp0.summer-workbench-port" >nul 2>nul
  start "Summer Workbench Local Server" /min py local_server.py
  goto wait_for_server
  exit /b
)
where python >nul 2>nul
if %errorlevel%==0 (
  del "%~dp0.summer-workbench-port" >nul 2>nul
  start "Summer Workbench Local Server" /min python local_server.py
  goto wait_for_server
  exit /b
)
echo 需要安装 Python 3 后再启动。
pause
exit /b

:wait_for_server
for /l %%i in (1,1,100) do (
  if exist "%~dp0.summer-workbench-port" goto open_workbench
  timeout /t 1 /nobreak >nul
)
echo 本地服务启动失败，请重新双击启动文件。
pause
exit /b

:open_workbench
set /p PORT=<"%~dp0.summer-workbench-port"
start "" "http://127.0.0.1:%PORT%/"
